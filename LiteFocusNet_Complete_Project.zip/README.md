# LiteFocusNet Complete Project
完整工程包含 litefocus_net.py, dataset.py, utils.py, train.py, infer.py, 可直接训练和推理。