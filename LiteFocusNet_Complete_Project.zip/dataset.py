import os
import torch
from torch.utils.data import Dataset
from PIL import Image

class CornLeafDataset(Dataset):
    def __init__(self, root_dir, transform=None):
        self.img_dir = os.path.join(root_dir, 'images')
        self.label_dir = os.path.join(root_dir, 'labels')
        self.img_files = sorted([f for f in os.listdir(self.img_dir) if f.endswith('.jpg')])
        self.transform = transform

    def __len__(self):
        return len(self.img_files)

    def __getitem__(self, idx):
        img_path = os.path.join(self.img_dir,self.img_files[idx])
        label_path = os.path.join(self.label_dir,self.img_files[idx].replace('.jpg','.txt'))
        image = Image.open(img_path).convert('RGB')
        bboxes, labels = [], []
        with open(label_path,'r') as f:
            for line in f:
                parts = line.strip().split()
                cls = int(parts[0])
                x,y,w,h = map(float, parts[1:])
                labels.append(cls)
                bboxes.append([x,y,w,h])
        bboxes = torch.tensor(bboxes,dtype=torch.float32)
        labels = torch.tensor(labels,dtype=torch.long)
        if self.transform:
            image = self.transform(image)
        target = {'boxes':bboxes,'labels':labels}
        return image, target
