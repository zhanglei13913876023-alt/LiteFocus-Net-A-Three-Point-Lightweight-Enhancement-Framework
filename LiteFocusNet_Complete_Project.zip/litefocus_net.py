import torch
import torch.nn as nn
import torch.nn.functional as F

class AKLBlock(nn.Module):
    def __init__(self, in_channels, out_channels, stride=1, tau=1.0, training=True):
        super().__init__()
        self.tau = tau
        self.training_mode = training
        self.dw3 = nn.Conv2d(in_channels, in_channels, 3, stride, 1, groups=in_channels, bias=False)
        self.dw5 = nn.Conv2d(in_channels, in_channels, 5, stride, 2, groups=in_channels, bias=False)
        self.dw7 = nn.Conv2d(in_channels, in_channels, 7, stride, 3, groups=in_channels, bias=False)
        self.pw = nn.Conv2d(in_channels, out_channels, 1, bias=False)
        self.bn = nn.BatchNorm2d(out_channels)
        self.relu = nn.ReLU(inplace=True)
        self.gate_logits = nn.Parameter(torch.zeros(3))
        self.global_pool = nn.AdaptiveAvgPool2d(1)

    def forward(self, x):
        g = self.global_pool(x).flatten(1)
        if self.training_mode:
            weights = F.gumbel_softmax(self.gate_logits, tau=self.tau, hard=False)
        else:
            idx = torch.argmax(self.gate_logits)
            weights = torch.zeros_like(self.gate_logits)
            weights[idx] = 1.0
        out = weights[0]*self.dw3(x) + weights[1]*self.dw5(x) + weights[2]*self.dw7(x)
        out = self.pw(out)
        out = self.bn(out)
        return self.relu(out)

class FDR(nn.Module):
    def __init__(self, in_channels, out_channels, detail_channels=16, upsample_mode='pixelshuffle'):
        super().__init__()
        self.structure_conv = nn.Conv2d(in_channels, out_channels, 3, padding=1)
        self.detail_conv = nn.Conv2d(in_channels, detail_channels, 3, padding=1)
        self.detail_recon = nn.Conv2d(detail_channels, out_channels, 3, padding=1)
        self.upsample_mode = upsample_mode
        self.pixelshuffle = nn.PixelShuffle(upscale_factor=2)

    def forward(self, x):
        structure = self.structure_conv(x)
        detail = F.relu(self.detail_conv(x))
        if self.upsample_mode == 'pixelshuffle':
            if detail.shape[1] % 4 == 0:
                detail = self.pixelshuffle(detail)
        else:
            detail = F.interpolate(detail, size=structure.shape[2:], mode='bilinear', align_corners=False)
        detail = self.detail_recon(detail)
        return structure + detail

class SAGBLoss(nn.Module):
    def __init__(self, alpha=2.0, beta=1.0):
        super().__init__()
        self.alpha = alpha
        self.beta = beta

    def forward(self, pred, target, obj_area=None, feature_level=None):
        base_loss = F.mse_loss(pred, target, reduction='none').sum(-1)
        if obj_area is not None:
            base_loss *= torch.exp(-self.beta * obj_area)
        if feature_level is not None:
            base_loss *= torch.exp(-self.alpha * feature_level)
        return base_loss.mean()

class LiteFocusNet(nn.Module):
    def __init__(self, num_classes=8, training=True):
        super().__init__()
        self.training_mode = training
        self.conv1 = nn.Conv2d(3,32,3,1,1)
        self.bn1 = nn.BatchNorm2d(32)
        self.relu = nn.ReLU(inplace=True)
        self.akl1 = AKLBlock(32,64, training=training)
        self.akl2 = AKLBlock(64,128, training=training)
        self.fdr1 = FDR(128,128)
        self.fdr2 = FDR(128,128)
        self.cls_head = nn.Conv2d(128,num_classes,1)
        self.reg_head = nn.Conv2d(128,4,1)

    def forward(self, x):
        x = self.relu(self.bn1(self.conv1(x)))
        x = self.akl1(x)
        x = self.akl2(x)
        x = self.fdr1(x)
        x = self.fdr2(x)
        cls_out = self.cls_head(x)
        reg_out = self.reg_head(x)
        return cls_out, reg_out
