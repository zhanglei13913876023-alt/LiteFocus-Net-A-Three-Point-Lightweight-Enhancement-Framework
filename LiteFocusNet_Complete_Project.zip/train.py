# training script
# 可自行引用 litefocus_net 和 dataset 进行训练
