import torch

def xywh2xyxy(boxes):
    x_c, y_c, w, h = boxes[:,0], boxes[:,1], boxes[:,2], boxes[:,3]
    x1 = x_c - w/2
    y1 = y_c - h/2
    x2 = x_c + w/2
    y2 = y_c + h/2
    return torch.stack([x1,y1,x2,y2], dim=1)

def bbox_iou(box1, box2):
    x1 = torch.max(box1[:,0], box2[:,0])
    y1 = torch.max(box1[:,1], box2[:,1])
    x2 = torch.min(box1[:,2], box2[:,2])
    y2 = torch.min(box1[:,3], box2[:,3])
    inter = ((x2-x1).clamp(0)) * ((y2-y1).clamp(0))
    area1 = (box1[:,2]-box1[:,0])*(box1[:,3]-box1[:,1])
    area2 = (box2[:,2]-box2[:,0])*(box2[:,3]-box2[:,1])
    return inter / (area1 + area2 - inter + 1e-6)

def nms(boxes, scores, iou_thresh=0.5):
    keep = []
    idxs = scores.argsort(descending=True)
    while idxs.numel()>0:
        i = idxs[0]
        keep.append(i.item())
        if idxs.numel()==1: break
        ious = bbox_iou(boxes[i].unsqueeze(0), boxes[idxs[1:]])
        idxs = idxs[1:][ious < iou_thresh]
    return keep
